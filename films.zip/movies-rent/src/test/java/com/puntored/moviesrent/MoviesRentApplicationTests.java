package com.puntored.moviesrent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesRentApplicationTests {

	@Test
	void contextLoads() {
	}

}
