package com.puntored.moviesrent.films.repository;

import com.puntored.moviesrent.films.dto.AvailableFilms;
import com.puntored.moviesrent.films.entity.FilmEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FilmRepository extends JpaRepository<FilmEntity, Integer> {

    @Query(value = "select s.address, i.quantity from store s inner join inventory i on s.store_id = i.store_id inner join film f on i.film_id = f.film_id where f.film_id = :filmId", nativeQuery = true)
    List<Object> findStoreByFilm(@Param("filmId") int filmId);

}
