package com.puntored.moviesrent.categories.controller;

import com.puntored.moviesrent.categories.entity.CategoryEntity;
import com.puntored.moviesrent.categories.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/category")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryRepository categoryRepository;

    @GetMapping
    private List<CategoryEntity> getAllCategories() {
        return categoryRepository.findAll();
    }

}
