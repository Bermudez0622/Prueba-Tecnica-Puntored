package com.puntored.moviesrent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesRentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesRentApplication.class, args);
	}

}
