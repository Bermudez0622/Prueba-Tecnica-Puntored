insert into category values(1, 'Accion', 'Accion');
insert into category values(2, 'Terror', 'Terror');
insert into category values(3, 'Comedia', 'Comedia');
insert into category values(4, 'Drama', 'Drama');

insert into store values(1, 'Dir 1');
insert into store values(2, 'Dir 2');
insert into store values(3, 'Dir 3');
insert into store values(4, 'Dir 4');