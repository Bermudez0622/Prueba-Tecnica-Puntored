package com.puntored.moviesrent.films.entity;

import com.puntored.moviesrent.categories.entity.CategoryEntity;
import com.puntored.moviesrent.films.dto.FilmDTO;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.List;

@Entity
@Table(name = "film")
@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class FilmEntity {

    @Id
    @Column(name = "film_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FILM_SEQ")
    @SequenceGenerator(name = "FILM_SEQ", sequenceName = "FILM_SEQ", allocationSize = 1)
    private int filmId;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "\"year\"")
    private int year;

    @Column(name = "rental_duration")
    private int rentalDuration;

    @Column(name = "rating")
    private int rating;

    @Column(name = "duration")
    private  int duration;

    @Column(name = "rental_price")
    private int rentalPrice;

    @ManyToMany
    @JoinTable(
            name = "filmcategory",
            joinColumns = @JoinColumn(
                    name = "film_id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "category_id"
            )
    )
    private List<CategoryEntity> categories;

    public static FilmEntity build(FilmDTO request) {
        return FilmEntity
                .builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .year(request.getYear())
                .rentalDuration(request.getRentalDuration())
                .rating(request.getRating())
                .duration(request.getDuration())
                .rentalPrice(request.getRentalPrice())
                .categories(Arrays.stream(request.getCategories()).mapToObj(category -> CategoryEntity.builder().categoryId(category).build()).toList())
                .build();
    }

}
