package com.puntored.moviesrent.films.repository;

import com.puntored.moviesrent.films.entity.FilmEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilmRepository extends JpaRepository<FilmEntity, Integer> {
}
