package com.puntored.moviesrent.films.controller;

import com.puntored.moviesrent.films.dto.FilmDTO;
import com.puntored.moviesrent.films.entity.FilmEntity;
import com.puntored.moviesrent.films.repository.FilmRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/film")
@RequiredArgsConstructor
public class FilmController {

    private final FilmRepository filmRepository;

    @GetMapping
    private List<FilmEntity> getAllMovies() {
        return filmRepository.findAll();
    }

    @PostMapping
    private FilmEntity saveFilm(
            @Validated @RequestBody FilmDTO request
            ) {
        return filmRepository.save(
                FilmEntity.build(request)
        );
    }

}
