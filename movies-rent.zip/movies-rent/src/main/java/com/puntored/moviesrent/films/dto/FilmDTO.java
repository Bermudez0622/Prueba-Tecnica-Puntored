package com.puntored.moviesrent.films.dto;

import lombok.Data;

@Data
public class FilmDTO {

    private String title;

    private String description;

    private int year;

    private int rentalDuration;

    private int rating;

    private  int duration;

    private int rentalPrice;

    private int[] categories;

}
