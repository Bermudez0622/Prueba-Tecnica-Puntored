create table category(
    category_id integer primary key,
    name varchar not null,
    description text not null
);

create table filmcategory(
    filmcategory_id integer primary key,
    film_id integer not null,
    category_id integer not null
);

create table film(
    film_id identity primary key,
    title varchar not null,
    description text not null,
    "year" integer not null,
    rental_duration integer not null,
    rating integer not null,
    duration integer not null,
    rental_price integer not null
);

create table inventory(
    inventory_id integer primary key,
    film_id integer not null,
    store_id integer not null,
    quantity integer not null
);

create table store(
    store_id integer primary key,
    address text not null
);

alter table filmcategory add constraint FILM_FILMCATEGORY_FK foreign key(film_id) references film(film_id);
alter table filmcategory add constraint CATEGORY_FILMCATEGORY_FK foreign key(category_id) references category(category_id);

alter table inventory add constraint FILM_INVENTORY_FK foreign key(film_id) references film(film_id);
alter table inventory add constraint STORE_INVENTORY_FK foreign key(store_id) references store(store_id);

create sequence FILM_SEQ start with 3 increment by 1;