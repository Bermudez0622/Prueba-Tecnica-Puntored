insert into category values(1, 'Accion', 'Accion');
insert into category values(2, 'Terror', 'Terror');
insert into category values(3, 'Comedia', 'Comedia');
insert into category values(4, 'Drama', 'Drama');

insert into film values(1, '', '', 0, 0, 0, 0, 0);
insert into film values(2, '', '', 0, 0, 0, 0, 0);

insert into filmcategory values(1, 1, 1);
insert into filmcategory values(2, 1, 2);
insert into filmcategory values(3, 1, 3);
insert into filmcategory values(4, 2, 4);
insert into filmcategory values(5, 1, 4);